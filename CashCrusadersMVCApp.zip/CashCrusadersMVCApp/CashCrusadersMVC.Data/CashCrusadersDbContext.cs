using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace CashCrusadersMVC.Data
{
    public partial class CashCrusadersDbContext : DbContext
    {
        public CashCrusadersDbContext()
            : base("CashCrusadersDbContext")
        {
        }

        public virtual DbSet<OrderLine> OrderLines1 { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Sale> Sales { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OrderLine>()
                .HasMany(e => e.Orders)
                .WithMany(e => e.OrderLines)
                .Map(m => m.ToTable("OrderLine").MapLeftKey("LineID").MapRightKey("OrderId"));

            modelBuilder.Entity<Product>()
                .Property(e => e.Price)
                .HasPrecision(18, 0);
        }
    }
}
