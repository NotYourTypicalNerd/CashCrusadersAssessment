﻿using CashCrusadersMVC.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashCrusaders.DAL.Interfaces
{
    public interface IproductRepository : IDisposable
    {
        Task<List<Product>> GetProducts();
        Task<Product> GetProductById(int id);
        Task UpdateProduct(Product product);
        Task DeleteProductById(int id);
        Task AddProduct(Product product);
    }
}
