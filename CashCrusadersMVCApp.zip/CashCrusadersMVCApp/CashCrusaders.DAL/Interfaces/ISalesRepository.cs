﻿using CashCrusadersMVC.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashCrusaders.DAL.Interfaces
{
    public interface ISalesRepository : IDisposable
    {
        Task<List<Sale>> GetSales();

        /// <summary>
        /// This method will be invoked when a new order is added or updated.
        /// Was ideally going to use a stored procedure to infer this data, but the requirement is to create separate table
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        Task AddOrUpdateSalesTotals(DateTime date);

        Task<Sale> GetSalesByDay(DateTime date);
    }
}
