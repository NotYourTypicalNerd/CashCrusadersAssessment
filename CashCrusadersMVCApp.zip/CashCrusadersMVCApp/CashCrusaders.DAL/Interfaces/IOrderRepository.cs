﻿using CashCrusadersMVC.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashCrusaders.DAL.Interfaces
{
    public interface IOrderRepository : IDisposable
    {
        Task<List<Order>> GetOrders();
        Task<Order> GetOrderById(int id);
        Task UpdateOrder(Order product);
        Task DeleteOrderById(int id);
        Task AddOrder(Order product);
    }
}
