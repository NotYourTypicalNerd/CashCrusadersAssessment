﻿using CashCrusaders.DAL.Interfaces;
using CashCrusadersMVC.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashCrusaders.DAL.Implementation
{
    public class SalesRepository : ISalesRepository
    {
        private CashCrusadersDbContext cashCrusadersDbContext;

        public SalesRepository()
        {
            cashCrusadersDbContext = new CashCrusadersDbContext();
        }
        public async Task AddOrUpdateSalesTotals(DateTime date)
        {
            var sale = await GetSalesByDay(date);

            if(sale == null)
            {
                cashCrusadersDbContext.Sales.Add(new Sale()
                {
                    Date = date,
                    Orders = 1
                });
            }
            else
            {
                sale.Orders += 1;
                cashCrusadersDbContext.Entry(sale).State = EntityState.Modified;
            }

            await cashCrusadersDbContext.SaveChangesAsync();
        }

        public void Dispose()
        {

            cashCrusadersDbContext.Dispose();
        }

        public async Task<List<Sale>> GetSales()
        {
            var model = await cashCrusadersDbContext.Sales.ToListAsync();

            return model;
        }

        public async Task<Sale> GetSalesByDay(DateTime date)
        {
            var sale = await cashCrusadersDbContext.Sales.FirstOrDefaultAsync(c => c.Date == date);

            return sale;
        }
    }
}
