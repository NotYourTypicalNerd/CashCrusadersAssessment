﻿using CashCrusaders.DAL.Interfaces;
using CashCrusadersMVC.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace CashCrusaders.DAL.Implementation
{
    //To do: write a generic interface that all repositories implements 
    public class OrderRepository : IOrderRepository, IDisposable
    {
        private CashCrusadersDbContext cashCrusadersDbContext;

        public OrderRepository()
        {
            cashCrusadersDbContext = new CashCrusadersDbContext();
        }
        public async Task AddOrder(Order order)
        {
            cashCrusadersDbContext.Orders.Add(order);
            await cashCrusadersDbContext.SaveChangesAsync();
        }

        public async Task DeleteOrderById(int id)
        {
            var order = new Order { ID = id };
            cashCrusadersDbContext.Entry(order).State = EntityState.Deleted;
            await cashCrusadersDbContext.SaveChangesAsync();
        }

        public void Dispose()
        {
            cashCrusadersDbContext.Dispose();
        }

        public async Task<Order> GetOrderById(int id)
        {
            var order = await cashCrusadersDbContext.Orders.FindAsync(id);
            return order;
        }

        public async Task<List<Order>> GetOrders()
        {
            var orders = await cashCrusadersDbContext.Orders.Include(c => c.OrderLines).ToListAsync();

            return orders;
        }

        public async Task UpdateOrder(Order order)
        {
            cashCrusadersDbContext.Entry(order).State = EntityState.Modified;
            await cashCrusadersDbContext.SaveChangesAsync();
        }
    }
}
