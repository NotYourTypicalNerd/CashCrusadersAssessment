﻿using CashCrusaders.DAL.Interfaces;
using CashCrusadersMVC.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace CashCrusaders.DAL.Implementation
{
    public class ProductRepository : IproductRepository, IDisposable
    {
        private CashCrusadersDbContext cashCrusadersDbContext;

        public ProductRepository()
        {
            cashCrusadersDbContext = new CashCrusadersDbContext();
        }
        public async Task AddProduct(Product product)
        {
            cashCrusadersDbContext.Products.Add(product);
            await cashCrusadersDbContext.SaveChangesAsync();
        }

        public async Task DeleteProductById(int id)
        {
            var product = new Product { ID = id };
            cashCrusadersDbContext.Entry(product).State = EntityState.Deleted;
            await cashCrusadersDbContext.SaveChangesAsync();
        }

        public void Dispose()
        {
            cashCrusadersDbContext.Dispose();
        }

        public async Task<Product> GetProductById(int id)
        {
            var product = await cashCrusadersDbContext.Products.FindAsync(id);
            return product;
        }

        public async Task<List<Product>> GetProducts()
        {
            var products = await cashCrusadersDbContext.Products.ToListAsync();

            return products;
        }

        public async Task UpdateProduct(Product product)
        {
            cashCrusadersDbContext.Entry(product).State = EntityState.Modified;
            await cashCrusadersDbContext.SaveChangesAsync();
        }
    }
}
