﻿using CashCrusadersMVC.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CashCrusadersMVCApp.Models
{
    public class OrderModel
    {
        public int ID { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Date only")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }
        public decimal Total { get; set; }
        public List<OrderLine> orderLines { get; set; }

        public List<ProductViewModel> Products { get; set; }

    }
}