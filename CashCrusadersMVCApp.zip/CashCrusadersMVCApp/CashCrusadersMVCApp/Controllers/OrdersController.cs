﻿using CashCrusaders.DAL.Interfaces;
using CashCrusadersMVC.Data;
using CashCrusadersMVCApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CashCrusadersMVCApp.Controllers
{
    public class OrdersController : Controller
    {
        private readonly IproductRepository productRepository;
        private readonly IOrderRepository orderRepository;
        private readonly ISalesRepository salesRepository;

        public OrdersController(IproductRepository repository, IOrderRepository orderRepository, ISalesRepository salesRepository)
        {
            this.productRepository = repository;
            this.orderRepository = orderRepository; 
            this.salesRepository = salesRepository;
        }
        // GET: Orders
        public async Task<ActionResult> Index()
        {
            var model = await orderRepository.GetOrders();
            return View(model);
        }

        // GET: Orders/Details/5
        public async Task<ActionResult> Details(int id)
        {
            var model = await orderRepository.GetOrderById(id);
            return View(model);
        }

        // GET: Orders/Create
        public async Task<ActionResult> Create()
        {
            var products = await productRepository.GetProducts();
            var model = new OrderModel()
            {
                Date = DateTime.Now,
                orderLines = new List<CashCrusadersMVC.Data.OrderLine>(),
                Products = products.Select(c => new ProductViewModel()
                {
                    ID = c.ID,
                    Name = c.Name
                }).ToList()
            };

            model.orderLines.Add(new CashCrusadersMVC.Data.OrderLine());

            return View(model);
        }

        // POST: Orders/AddLineItem
        [HttpPost]
        public async Task<ActionResult> AddLineItem(OrderModel model)
        {
            //Should ideally cache this. Running out of time
            var products = await productRepository.GetProducts();

            model.orderLines.Add(new CashCrusadersMVC.Data.OrderLine());
            model.Products = products.Select(c => new ProductViewModel()
            {
                ID = c.ID,
                Name = c.Name
            }).ToList();

            return View("Create", model);
        }

        // POST: Orders/Create
        [HttpPost]
        public async Task<ActionResult> Create(OrderModel model)
        {
            Order order = null;
            try
            {
                if(model.ID != 0)
                {
                    order = await orderRepository.GetOrderById(model.ID);
                }
                else
                {
                    order = new Order()
                    {
                        Date = model.Date
                    };
                }

                foreach(var ol in model.orderLines)
                {
                    var product = await productRepository.GetProductById(ol.Product.Value);

                    //mistakenly assumed this is an int field. No time to refactor the code.
                    order.Total += Convert.ToInt32(ol.Quantity * product.Price);
                }

                order.OrderLines = model.orderLines;

                if (order.ID == 0)
                {
                    await orderRepository.AddOrder(order);
                }
                else
                {
                    await orderRepository.UpdateOrder(order);
                }


                //This should ideally be in a view(not stored in a table
                await salesRepository.AddOrUpdateSalesTotals(order.Date);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Orders/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            var products = await productRepository.GetProducts();
            var model = await orderRepository.GetOrderById(id);
            var vm = new OrderModel()
            {
                Products = products.Select(c => new ProductViewModel()
                {
                    ID = c.ID,
                    Name = c.Name
                }).ToList(),
                ID = model.ID,
                Date = model.Date,
                orderLines = model.OrderLines.ToList()
            };

            return View("Create", vm);
        }

        // POST: Orders/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Orders/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Orders/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
