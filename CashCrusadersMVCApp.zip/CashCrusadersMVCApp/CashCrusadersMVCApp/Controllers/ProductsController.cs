﻿using CashCrusaders.DAL.Implementation;
using CashCrusaders.DAL.Interfaces;
using CashCrusadersMVC.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CashCrusadersMVCApp.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IproductRepository productRepository;

        public ProductsController(IproductRepository repository)
        {
            this.productRepository = repository;
        }

        // GET: Products
        public async Task<ActionResult> Index()
        {
            var products = await productRepository.GetProducts();

            return View(products);
        }

        
        // GET: Products/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Products/Create
        [HttpPost]
        public async Task<ActionResult> Create(Product product)
        {
            try
            {
                await productRepository.AddProduct(product);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Products/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
           var product = await productRepository.GetProductById(id);
            
            return View(product);
        }

        // POST: Products/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(Product product)
        {
            try
            {
                await productRepository.UpdateProduct(product);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Products/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            var product = await productRepository.GetProductById(id);
            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost]
        public async Task<ActionResult> Delete(int id, FormCollection collection)
        {
            try
            {
                await productRepository.DeleteProductById(id);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
